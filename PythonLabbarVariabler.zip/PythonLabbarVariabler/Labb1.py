print("Hello world")
