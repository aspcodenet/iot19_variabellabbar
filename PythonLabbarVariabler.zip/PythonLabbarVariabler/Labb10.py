sum = int(input("Ange en summa"))
moms = sum * 0.25
sum = sum + moms
print("Pris med moms:", sum)

print(f'pris med moms: {sum}')