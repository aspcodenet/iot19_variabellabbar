forName = input("Skriv in ditt förnamn:")
surName = input("Skriv in ditt efternamn")
print("Du heter ", surName + "," + forName)

