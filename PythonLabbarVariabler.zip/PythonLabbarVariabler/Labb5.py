print("Mata in ett tal")
tal1 = int(input())
print("Mata in ett tal till")
tal2 = int(input())

print("Summan av {0} and {1} is :{2}".format(tal1,tal2,tal1+tal2))
#tal3 = tal1+tal2
print("Summan av ",tal1, " and ",tal2, " is:",tal1+tal2)
